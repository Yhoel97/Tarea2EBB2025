from controller import Robot
import datetime

# ===== CONFIGURACIÓN GENERAL =====
TIME_STEP = 64
MAX_SPEED = 6.28

robot = Robot()

# Sensores de proximidad
prox_sensors = []
for i in range(8):
    sensor = robot.getDevice(f'ps{i}')
    sensor.enable(TIME_STEP)
    prox_sensors.append(sensor)

# Cámara (opcional)
try:
    camera = robot.getDevice("camera")
    camera.enable(TIME_STEP)
except:
    camera = None

# Motores
left_motor = robot.getDevice('left wheel motor')
right_motor = robot.getDevice('right wheel motor')
left_motor.setPosition(float('inf'))
right_motor.setPosition(float('inf'))
left_motor.setVelocity(0.0)
right_motor.setVelocity(0.0)

# LEDs
leds = []
for i in range(10):
    try:
        led = robot.getDevice(f'led{i}')
        leds.append(led)
    except:
        pass

def set_led_state(state: str):
    colors = {
        'go': (1, 0, 0),       # Verde
        'turning': (0, 0, 1),  # Azul
        'obstacle': (0, 1, 0), # Rojo
        'stuck': (1, 0, 1),    # Violeta
    }
    r, g, b = colors.get(state, (0, 0, 0))
    for led in leds:
        led.set(r + g * 2 + b * 4)

def read_proximity(index):
    return prox_sensors[index].getValue()

# Métricas
start_time = robot.getTime()
distance = 0.0
collisions = 0
stuck_counter = 0
max_stuck = 50

def navigate():
    global collisions, stuck_counter

    front_left = read_proximity(0)
    front_right = read_proximity(7)
    side_right = read_proximity(2)

    obstacle_ahead = front_left > 80 or front_right > 80
    right_clear = side_right < 60

    if front_left > 100 and front_right > 100:
        collisions += 1
        set_led_state('obstacle')
        left_motor.setVelocity(-0.5 * MAX_SPEED)
        right_motor.setVelocity(-0.5 * MAX_SPEED)
        stuck_counter += 1
        for _ in range(5):
            robot.step(TIME_STEP)
        return

    if obstacle_ahead:
        set_led_state('turning')
        left_motor.setVelocity(0.4 * MAX_SPEED)
        right_motor.setVelocity(-0.4 * MAX_SPEED)
        stuck_counter += 1
    elif right_clear:
        set_led_state('turning')
        left_motor.setVelocity(0.6 * MAX_SPEED)
        right_motor.setVelocity(0.2 * MAX_SPEED)
        stuck_counter = 0
    else:
        set_led_state('go')
        left_motor.setVelocity(0.5 * MAX_SPEED)
        right_motor.setVelocity(0.5 * MAX_SPEED)
        stuck_counter = 0

# ===== BUCLE PRINCIPAL =====
print("✅ Controlador iniciado correctamente.")

while robot.step(TIME_STEP) != -1 and stuck_counter < max_stuck:
    navigate()
    v_left = left_motor.getVelocity()
    v_right = right_motor.getVelocity()
    v_avg = (v_left + v_right) / 2
    distance += abs(v_avg * (TIME_STEP / 1000))

# Detener motores
left_motor.setVelocity(0)
right_motor.setVelocity(0)

if stuck_counter >= max_stuck:
    set_led_state('stuck')
    print("⚠️ Robot atascado. Detenido por seguridad.")

# ===== RESULTADOS =====
end_time = robot.getTime()
total_time = end_time - start_time

print("\n📊 RESULTADOS DE NAVEGACIÓN")
print(f"⏱ Tiempo total     : {total_time:.2f} s")
print(f"📏 Distancia aprox. : {distance:.2f} unidades")
print(f"💥 Colisiones       : {collisions}")
print(f"Estado final        : {'Atascado' if stuck_counter >= max_stuck else 'Finalizado correctamente'}")

# Guardar en archivo
fecha = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
try:
    with open(f"resultados_navegacion_{fecha}.txt", "w") as file:
        file.write("===== RESULTADOS DE NAVEGACIÓN =====\n")
        file.write(f"Tiempo total     : {total_time:.2f} s\n")
        file.write(f"Distancia aprox. : {distance:.2f} unidades\n")
        file.write(f"Colisiones       : {collisions}\n")
        file.write(f"Estado final     : {'Atascado' if stuck_counter >= max_stuck else 'Finalizado correctamente'}\n")
    print("📝 Resultados guardados exitosamente.")
except:
    print("⚠️ No se pudo guardar el archivo de resultados.")
